from django.urls import path
from .import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('',views.layout, name='layout'),
    path('register/',views.register_user, name='register_user'),
    path('login/',views.login_view, name='login_view'),
    path('view/<int:Item_id>',views.view_product, name='view_product'),
    # path('add/<int:Item_id>',views.add_to_cart, name='add_to_cart'),
    path('shipping/',views.checkout, name='checkout'),
    path('cart/', views.cart_view, name='cart_view'),
    path('add_to_cart/<int:Item_id>/', views.add_to_cart, name='add_to_cart'),
    path('remove_from_cart/<int:cart_item_id>/', views.remove_from_cart, name='remove_from_cart'),
    path('update_cart/<int:cart_item_id>/', views.update_cart, name='update_cart'),
    path('logout/',views.log_out, name='log_out'),
    path('search/',views.search_product, name='search_product'),
    path("about/",views.about, name = "about"),
    path('order/',views.view_orders, name = "view_orders"),
    path('offer/',views.Offer, name = "Offer"),
    path("order_detail/<int:order_id>/",views.order_details, name = 'order_details'),
    path('contactadmin/',views.contact, name = 'contact'),
    
]
if settings.DEBUG:
    urlpatterns +=static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
