from django.contrib import admin
from .models import Products, Orders,Cart, CartItem, OrderItems,Contact_admin
# Register your models here.
admin.site.register(Products)
admin.site.register(Orders)
admin.site.register(Cart)
admin.site.register(CartItem)
admin.site.register(OrderItems)
admin.site.register(Contact_admin)
# admin.site.register(OrderItem)
# class Adminorder(admin.ModelAdmin):
#     list_display = [field.name for field in Orders._meta.fields]
