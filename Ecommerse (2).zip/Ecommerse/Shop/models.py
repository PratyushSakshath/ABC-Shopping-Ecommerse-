from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class Products(models.Model):
    Item_id = models.IntegerField(primary_key=True)
    Item_image=models.ImageField()
    Item_price=models.IntegerField()
    Item_name=models.CharField(max_length=100)
    Item_description=models.TextField(blank=True)
    def __str__(self):
        return self.Item_name



    
# class add_Products(models.Model):
#     selected_item=models.ForeignKey(Products, on_delete=models.PROTECT)
#     username = models.ForeignKey('auth.User', on_delete=models.CASCADE)
#     quantity = models.PositiveIntegerField(default=1)

class Cart(models.Model):
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    total_price = models.DecimalField(max_digits=100, decimal_places=4, default=0.00)
    # created_at = models.DateTimeField(auto_now_add=True)
    # updated_at = models.DateTimeField(auto_now=True)

    def _str_(self):
        return self.user

class CartItem(models.Model):
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE)
    product = models.ForeignKey(Products, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)
    # created_at = models.DateTimeField(auto_now_add=True)
    # updated_at = models.DateTimeField(auto_now=True)

    def _str_(self):
        return f"{self.product.product_name} x {self.quantity}"

# class order_place(models.Model):
#     fk = models.ForeignKey(Orders, on_delete=models.CASCADE)
#     carts = models.ForeignKey(CartItem, on_delete=models.PROTECT)
#     time=models.DateTimeField(auto_now=True)


# class Order(models.Model):
#     user = models.ForeignKey(User, on_delete=models.CASCADE)
#     total_price = models.DecimalField(max_digits=10, decimal_places=2)
#     created_at = models.DateTimeField(auto_now_add=True)
#     is_active = models.BooleanField(default=True)

#     def __str__(self):
#         return self.user.username

# class OrderItem(models.Model):
#     order = models.ForeignKey(Order, on_delete=models.CASCADE)
#     product = models.ForeignKey('Products', on_delete=models.CASCADE)
#     quantity = models.IntegerField()
#     price = models.DecimalField(max_digits=10, decimal_places=2)

#     def __str__(self):
#         return f"{self.quantity} x {self.product.Item_name}"

class Orders(models.Model):
    
    # cart = models.ForeignKey(Cart, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.PROTECT)
    Name=models.CharField(max_length=50)
    Email=models.EmailField()
    Address=models.CharField(max_length=100)
    city=models.CharField(max_length=50)
    state=models.CharField(max_length=50)
    ZIP=models.IntegerField() 
    created_at = models.DateTimeField(auto_now=True)
    total_price = models.DecimalField(max_digits=100, decimal_places=4, default=0.00)
    status = models.CharField(max_length=50,default = 'Order Placed')



    #user detail and order should be visible after checkout
class OrderItems(models.Model):
    order = models.ForeignKey(Orders, on_delete=models.CASCADE)
    product = models.ForeignKey(Products, on_delete=models.PROTECT)
    quantity = models.IntegerField()

class Contact_admin(models.Model):
    Name = models.CharField(max_length=20)
    Email = models.EmailField(max_length=30)
    problem = models.TextField()
