from django import forms

from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Products, Cart, CartItem, Orders, Contact_admin

class Orderform(forms.ModelForm):
    class Meta:
        model=Orders
        exclude = ['user','total_price','created_at']

class UserRegistration(UserCreationForm):
    class Meta:
        model=User
        fields =["username", "email", "password1", "password2"]

class CartForm(forms.ModelForm):
    class Meta:
        model = CartItem
        fields = ['quantity']

class Contactform(forms.ModelForm):
    class Meta:
        model = Contact_admin
        fields = ['Name','Email','problem']

# class AddProductForm(forms.ModelForm):
#     class Meta:
#         model = add_Products
#         fields = ('selected_item', 'quantity', 'username')

#     def __init__(self, user, *args, **kwargs):
#         super(AddProductForm, self).__init__(*args, **kwargs)
#         print('adding', user)
#         self.fields['username'].initial = user

#     def save(self, commit=True):
#         instance = super(AddProductForm, self).save(commit=False)
#         instance.username = self.cleaned_data['username']
#         if commit:
#              instance.save()
#         return instance 