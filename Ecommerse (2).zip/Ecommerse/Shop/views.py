from django.shortcuts import render, redirect, get_object_or_404, get_list_or_404
from .forms import UserRegistration, CartForm, Contactform
from django.contrib.auth import login, authenticate
from .models import Products, Cart, CartItem, Orders, OrderItems
from django.contrib.auth.decorators import login_required
from .forms import Orderform
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import logout

# Create your views here.

def register_user(request):
    form=UserRegistration()
    if request.method == 'POST':
        form=UserRegistration(request.POST)
        if form.is_valid():
            user=form.save(commit = False)
            user.set_password(form.cleaned_data['password1'])
            form.save(commit = True)
            login(request, user)
            return redirect('layout')
    return render(request, 'Shop/register.html',{'form':form})

def layout(request):
    items=Products.objects.all()
    dict={'items':items}
    return render(request,'Shop/Home.html',dict)

def login_view(request):
    # user = authenticate(request, username=username, password=password)
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('layout')
        else:
            # Return an 'invalid login' error message.
            # message = "Please enter correct details"
            pass
          
    return render(request, 'Shop/login.html')
def view_product(request,Item_id):
    items=get_object_or_404(Products,Item_id=Item_id)
    dict={'items':items}
    return render(request,'Shop/view_product.html',dict)

def log_out(request):
    logout(request)
    return redirect('layout')
# @login_required
# def add_to_cart(request,Item_id):
    # # form = AddProductForm(request.user)
    # if request.method == 'GET':
    #     print('here', request)
    #     form = AddProductForm(request.user)
    #     form.fields['selected_item'].initial = Item_id  # Set selected_item
    #     form.fields['quantity'].initial = 1  # Set quantity to 1 (or any default value)
    #     if form.is_valid():
    #         print('valid')
    #         form.save(commit=True)
    #         return HttpResponse("item is send to the cart")
    #     print('errors',form.errors)
    #     return HttpResponse("failed")
    
#     pass

def search_product(request):
    query = request.GET.get('q')
    if query:
        results = Products.objects.filter(Item_name__icontains=query)
        if results.exists():
            return render(request, 'Shop/search.html', {'results': results})
        else:
            return render(request, 'Shop/search.html', {'message': 'No results found'})
    return render(request, 'search.html')

@login_required
def cart_view(request):
    cart,created = Cart.objects.get_or_create(user=request.user)
    cart_items = CartItem.objects.filter(cart=cart)#
    total_price = cart.total_price
    savings = 0
    if total_price > 2000 and total_price < 50001:
        savings = total_price*10/100
        total_price = total_price - savings
    elif total_price > 50000:
        savings = total_price*25/100
        total_price = total_price - savings
    else:
        pass
    return render(request, 'Shop/cart.html', {'cart_items': cart_items, 'total_price': total_price, 'savings': savings})

@login_required
def add_to_cart(request,Item_id):
    print(f"Adding product {Item_id} to cart...")
    product = Products.objects.get(Item_id=Item_id)
    cart, created = Cart.objects.get_or_create(user=request.user)
    cart_item, created = CartItem.objects.get_or_create(cart=cart, product=product)
    if created:
        cart_item.quantity = 1
    else:
        cart_item.quantity += 1
    cart_item.save()
    cart.total_price += product.Item_price * cart_item.quantity
    cart.save()
    return redirect('cart_view')

@login_required
def remove_from_cart(request, cart_item_id):
    cart_item = CartItem.objects.get(id=cart_item_id)
    cart_item.delete()
    cart = Cart.objects.get(user=request.user)
    cart.total_price -= cart_item.product.Item_price * cart_item.quantity
    cart.save()
    return redirect('cart_view')
@login_required
def update_cart(request, cart_item_id):
    cart_item = CartItem.objects.get(id=cart_item_id)
    form = CartForm(request.POST or None, instance=cart_item)
    if form.is_valid():
        form.save()
        cart = Cart.objects.get(user=request.user)
        cart.total_price = sum([item.product.Item_price * item.quantity for item in CartItem.objects.filter(cart=cart)])
        cart.save()
        return redirect('cart_view')
    return render(request, 'Shop/update_cart.html', {'form': form, 'cart_item':cart_item})

# @login_required
# def checkout(request):
   
#     if request.method == 'POST':
#         form=Orderform(request.POST)
#         if form.is_valid():
#             Orders = form.save(commit=False)
#             Orders.user = request.user
#             Orders.product = Products.objects.get('name')# multiple xx
#             Orders.quantity = CartItem.objects.get('quantity')
#             Orders.total_price = Cart.objects.get('total_price')
#             form.save(commit=True)
#             cart, created = Cart.objects.get_or_create(user=request.user)
#             cart.delete()
#             #write logic to remove all the items from the Cart
#             return redirect('layout')
#     return render(request,'Shop/orderform.html',{'form':form})

@login_required
def checkout(request):
    if request.method == 'POST':
        form = Orderform(request.POST)
        if form.is_valid():
            order = form.save(commit=False)
            order.user = request.user
            cart = Cart.objects.get(user=request.user)
            cart_item = CartItem.objects.filter(cart=cart).first()
            if cart_item:
                # order.product = cart_item.product
                # order.quantity = cart_item.quantity
                order.total_price = cart.total_price
                order.save()
                # cart.delete()  # Remove the cart after checkout
                return redirect('order_details',order_id =order.id)
    return render(request, 'Shop/orderform.html', {'form': form})
@login_required
def order_details(request,order_id):
    cart = Cart.objects.get(user=request.user)
    order = get_object_or_404(Orders, id=order_id)
    cart_item = CartItem.objects.filter(cart = cart)
    for item in cart_item:
        OrderItems.objects.create(
            order = order, 
            product=item.product, 
            quantity=item.quantity
            )
    cart.delete()
    return redirect('layout')

def about(request):
    return render(request,'Shop/about.html')

def view_orders(request):
    
    orders = Orders.objects.filter(user=request.user)
    
    
    order_id = request.GET.get('Orders.id')  # not getting order_id
    print(order_id)#None
    if order_id:
        try:
            order_id = int(order_id)  
            order = get_object_or_404(Orders, id=order_id, user=request.user)
            product_details = OrderItems.objects.filter(order=order)
        except ValueError:
            product_details = []
    else:
        product_details = []

    context = {
        'orders': orders,
        'product_details': product_details
    }
    
    return render(request, 'Shop/Orderlist.html', context)

def Offer(request):
    return render(request,'Shop/offer.html')

def contact(request):
    form = Contactform()
    if request.method == 'POST':
        form = Contactform(request.POST)
        if form.is_valid():
            form.save(commit = True)
    return render(request,"shop/contact.html",{'form':form})



